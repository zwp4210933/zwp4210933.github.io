//
//  ChatHistoryViewController.h
//  TestIM4
//
//  Created by Apple on 16/1/8.
//  Copyright © 2016年 lanjue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatHistoryViewController : UIViewController

@property (nonatomic, strong) NSString *friendName;


@end
