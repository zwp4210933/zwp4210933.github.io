//
//  ImageViewController.h
//  TestIM4
//
//  Created by Apple on 15/12/5.
//  Copyright © 2015年 lanjue. All rights reserved.
//

#import "ViewController.h"
/*查看大图试图控制器*/

@interface ImageViewController : ViewController

@property (nonatomic, strong) NSString *fileName;
@property (nonatomic, strong) NSString *friendName;

@end
