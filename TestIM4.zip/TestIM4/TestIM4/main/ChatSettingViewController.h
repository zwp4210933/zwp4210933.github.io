//
//  ChatSettingViewController.h
//  TestIM4
//
//  Created by Apple on 16/1/8.
//  Copyright © 2016年 lanjue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatSettingViewController : UIViewController

@property (nonatomic, strong) NSString *friendName;

@end
