//
//  MissionView.h
//  TestIM4
//
//  Created by Apple on 16/1/9.
//  Copyright © 2016年 lanjue. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Mission.h"

@interface MissionView : UIView

-(instancetype)initWithFrame:(CGRect)frame Modle:(Mission *)model;


@end
