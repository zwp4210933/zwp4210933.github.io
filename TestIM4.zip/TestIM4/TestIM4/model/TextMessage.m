//
//  TextMessage.m
//  TestIM4
//
//  Created by Apple on 15/11/26.
//  Copyright © 2015年 lanjue. All rights reserved.
//

#import "TextMessage.h"

@implementation TextMessage

@end
