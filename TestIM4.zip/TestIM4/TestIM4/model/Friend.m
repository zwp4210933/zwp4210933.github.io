//
//  Friend.m
//  TestIM4
//
//  Created by Apple on 15/12/10.
//  Copyright © 2015年 lanjue. All rights reserved.
//

#import "Friend.h"

@implementation Friend

@end
