//
//  Const.h
//  TestIM4
//
//  Created by Apple on 15/11/30.
//  Copyright © 2015年 lanjue. All rights reserved.
//

#ifndef Const_h
#define Const_h

typedef enum{
    WeChat,
    Phone
}RequestType;

#endif /* Const_h */
